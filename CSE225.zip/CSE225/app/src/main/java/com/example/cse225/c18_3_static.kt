package com.example.cse225
//onButtonPressedListener
//interface
interface c18_3_static {
    fun onButtonPressed(msg: String)
}