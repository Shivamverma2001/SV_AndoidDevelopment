package com.example.cse225

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class CA12 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ca12)
    }
}