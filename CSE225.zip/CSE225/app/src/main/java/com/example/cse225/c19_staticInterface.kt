package com.example.cse225

interface c19_staticInterface {
    fun onButtonPressed(msg: Int)
}