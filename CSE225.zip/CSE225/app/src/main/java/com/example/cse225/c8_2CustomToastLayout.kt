package com.example.cse225

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class c8_2CustomToastLayout : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_c82_custom_toast_layout)
    }
}