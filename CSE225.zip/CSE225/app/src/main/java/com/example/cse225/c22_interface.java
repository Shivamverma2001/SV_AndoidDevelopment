package com.example.cse225;

public interface c22_interface {
    //interface fun
}
