package com.example.cse225;

public interface c20interface {
}
